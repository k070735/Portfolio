var randompx = Math.floor(Math.random()*100)+1;

document.write((randompx+','));



var rain1=document.getElementsByClassName("rain1");
rain1.style.marginLeft = randompx+'px';




/*
	rain1 = document.getElementsByClassName("rain1");
	rain2 = document.getElementsByClassName("rain2");
	rain3 = document.getElementsByClassName("rain3");
*/
